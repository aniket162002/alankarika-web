"use strict";exports.id=6206,exports.ids=[6206],exports.modules={75593:(e,r,t)=>{t.d(r,{Z:()=>d});var o=t(9885);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),s=(...e)=>e.filter((e,r,t)=>!!e&&t.indexOf(e)===r).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var i={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,o.forwardRef)(({color:e="currentColor",size:r=24,strokeWidth:t=2,absoluteStrokeWidth:a,className:l="",children:d,iconNode:n,...c},m)=>(0,o.createElement)("svg",{ref:m,...i,width:r,height:r,stroke:e,strokeWidth:a?24*Number(t)/Number(r):t,className:s("lucide",l),...c},[...n.map(([e,r])=>(0,o.createElement)(e,r)),...Array.isArray(d)?d:[d]])),d=(e,r)=>{let t=(0,o.forwardRef)(({className:t,...i},d)=>(0,o.createElement)(l,{ref:d,iconNode:r,className:s(`lucide-${a(e)}`,t),...i}));return t.displayName=`${e}`,t}},56206:(e,r,t)=>{t.d(r,{Z:()=>a});var o=t(75593);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,o.Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])}};