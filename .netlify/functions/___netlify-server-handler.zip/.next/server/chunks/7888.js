"use strict";exports.id=7888,exports.ids=[7888],exports.modules={7382:(e,t,a)=>{a.d(t,{Z:()=>o});var l=a(75593);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,l.Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},43618:(e,t,a)=>{a.d(t,{f:()=>n});var l=a(9885),o=a(43979),r=a(60080),s=l.forwardRef((e,t)=>(0,r.jsx)(o.WV.label,{...e,ref:t,onMouseDown:t=>{let a=t.target;a.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));s.displayName="Label";var n=s}};